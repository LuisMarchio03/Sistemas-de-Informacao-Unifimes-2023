public class Main {
    public static void main(String[] args) {
        DRETree dreTree = new DRETree();
        Menu menu = new Menu(dreTree);
        menu.exibir();
    }
}
